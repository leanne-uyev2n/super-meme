# README

These are notebooks [Cohere](https://cohere.ai/) built in collaboration with Google.  They demonstrate how to use Cohere's modeling API along with Vertex AI.